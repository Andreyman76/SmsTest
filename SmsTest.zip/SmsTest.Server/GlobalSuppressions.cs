﻿// This file is used by Code Analysis to maintain SuppressMessage
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given
// a specific target and scoped to a namespace, type, member, etc.

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Style", "IDE0305:Упростите инициализацию коллекции", Justification = "<Ожидание>", Scope = "member", Target = "~M:SmsTest.Server.Services.InMemorySmsTestService.GetMenuAsync(SmsTest.Application.DTO.GetMenuRequestDto,System.Threading.CancellationToken)~System.Threading.Tasks.Task{SmsTest.Application.DTO.GetMenuResponseDto}")]
[assembly: SuppressMessage("Style", "IDE0060:Удалите неиспользуемый параметр", Justification = "<Ожидание>", Scope = "member", Target = "~M:SmsTest.Server.Services.InMemorySmsTestService.GetMenuAsync(SmsTest.Application.DTO.GetMenuRequestDto,System.Threading.CancellationToken)~System.Threading.Tasks.Task{SmsTest.Application.DTO.GetMenuResponseDto}")]
